function addNumbers() {   

var numberOne = parseInt(document.getElementById("firstNumber").value);
var numberTwo = parseInt(document.getElementById("secondNumber").value);

var total = parseInt(numberOne + numberTwo);

alert ("The total is " + total);
}